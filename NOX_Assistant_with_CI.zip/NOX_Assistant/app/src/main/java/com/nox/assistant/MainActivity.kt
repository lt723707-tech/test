package com.nox.assistant

import android.app.Activity
import android.os.Bundle
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.text.InputType
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.view.inputmethod.EditorInfo
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var expression: EditText
    private lateinit var result: TextView
    private lateinit var face: NoxFaceView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(5, 8, 15)
        window.navigationBarColor = Color.rgb(5, 8, 15)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            setBackgroundColor(Color.rgb(5, 8, 15))
        }

        val heading = TextView(this).apply {
            text = "N O X"
            textSize = 23f
            letterSpacing = 0.22f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(105, 213, 255))
        }
        page.addView(heading, LinearLayout.LayoutParams(-1, dp(42)))

        face = NoxFaceView(this)
        page.addView(face, LinearLayout.LayoutParams(-1, 0, 1f))

        val calcTitle = TextView(this).apply {
            text = "КАЛЬКУЛЯТОР"
            textSize = 12f
            letterSpacing = 0.16f
            setTextColor(Color.rgb(125, 150, 175))
        }
        page.addView(calcTitle, LinearLayout.LayoutParams(-1, dp(24)))

        expression = EditText(this).apply {
            hint = "Например: 2 + 2 * (3 - 1)"
            textSize = 18f
            singleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_DONE
            setTextColor(Color.WHITE)
            setHintTextColor(Color.rgb(95, 112, 132))
            setPadding(dp(14), 0, dp(14), 0)
            setBackgroundColor(Color.rgb(18, 27, 40))
            setOnEditorActionListener { _, _, _ -> calculate(); true }
        }
        page.addView(expression, LinearLayout.LayoutParams(-1, dp(54)))

        result = TextView(this).apply {
            text = "Ответ появится здесь"
            textSize = 24f
            gravity = Gravity.CENTER_VERTICAL or Gravity.END
            setTextColor(Color.rgb(90, 210, 255))
            setPadding(dp(4), 0, dp(4), 0)
        }
        page.addView(result, LinearLayout.LayoutParams(-1, dp(52)))

        val keys = listOf(
            listOf("7", "8", "9", "÷"),
            listOf("4", "5", "6", "×"),
            listOf("1", "2", "3", "−"),
            listOf("(", "0", ")", "+"),
            listOf("C", "⌫", "%", "=")
        )
        keys.forEach { row ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            row.forEach { key ->
                val button = Button(this).apply {
                    text = key
                    textSize = 18f
                    isAllCaps = false
                    setTextColor(if (key == "=") Color.BLACK else Color.rgb(190, 225, 245))
                    setBackgroundTintList(android.content.res.ColorStateList.valueOf(
                        if (key == "=") Color.rgb(85, 205, 250) else Color.rgb(22, 36, 52)
                    ))
                    setOnClickListener { onKey(key) }
                }
                line.addView(button, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            page.addView(line, LinearLayout.LayoutParams(-1, dp(54)))
        }

        setContentView(page)
    }

    private fun onKey(key: String) {
        when (key) {
            "C" -> { expression.setText(""); result.text = "Ответ появится здесь" }
            "⌫" -> {
                val s = expression.text.toString()
                if (s.isNotEmpty()) expression.setText(s.dropLast(1))
                expression.setSelection(expression.text.length)
            }
            "=" -> calculate()
            else -> {
                val insert = when (key) {
                    "÷" -> "/"
                    "×" -> "*"
                    "−" -> "-"
                    else -> key
                }
                val start = max(0, expression.selectionStart)
                val end = max(start, expression.selectionEnd)
                expression.text.replace(start, end, insert)
            }
        }
    }

    private fun calculate() {
        val raw = expression.text.toString().trim()
        if (raw.isEmpty()) return
        try {
            val value = Calculator(raw).parse()
            if (!value.isFinite()) throw IllegalArgumentException("Недопустимый результат")
            val formatted = if (value % 1.0 == 0.0 && kotlin.math.abs(value) < 1e15) {
                value.toLong().toString()
            } else String.format(Locale.US, "%.8f", value).trimEnd('0').trimEnd('.')
            result.text = formatted
            face.setHappy(true)
        } catch (_: Exception) {
            result.text = "Проверь выражение"
            face.setHappy(false)
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}

private class NoxFaceView(context: Context) : View(context) {
    private val eyePaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var happy = false
    private var blink = 0f
    private var lastBlink = System.currentTimeMillis()
    private var blinkStart = 0L

    fun setHappy(value: Boolean) {
        happy = value
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val t = System.currentTimeMillis()

        if (t - lastBlink > 3600 && blinkStart == 0L) {
            blinkStart = t
            lastBlink = t
        }
        if (blinkStart != 0L) {
            val elapsed = t - blinkStart
            blink = if (elapsed < 120) elapsed / 120f
                    else if (elapsed < 240) (240 - elapsed) / 120f else 0f
            if (elapsed >= 240) blinkStart = 0L
        }

        val eyeW = min(w * 0.19f, dp(78f))
        val eyeH = dp(55f) * (1f - blink * 0.92f)
        val gap = min(w * 0.12f, dp(48f))
        val radius = eyeH / 2f
        val left = RectF(cx - gap / 2f - eyeW, cy - eyeH / 2f, cx - gap / 2f, cy + eyeH / 2f)
        val right = RectF(cx + gap / 2f, cy - eyeH / 2f, cx + gap / 2f + eyeW, cy + eyeH / 2f)

        glowPaint.color = Color.argb(55, 45, 185, 255)
        glowPaint.style = Paint.Style.STROKE
        glowPaint.strokeWidth = dp(15f)
        canvas.drawRoundRect(left, radius, radius, glowPaint)
        canvas.drawRoundRect(right, radius, radius, glowPaint)

        eyePaint.color = if (happy) Color.rgb(135, 230, 255) else Color.rgb(75, 200, 255)
        eyePaint.style = Paint.Style.FILL
        canvas.drawRoundRect(left, radius, radius, eyePaint)
        canvas.drawRoundRect(right, radius, radius, eyePaint)

        if (blink == 0f) {
            eyePaint.color = Color.WHITE
            val pupilR = dp(5f)
            canvas.drawCircle(left.centerX(), cy, pupilR, eyePaint)
            canvas.drawCircle(right.centerX(), cy, pupilR, eyePaint)
        }
        postInvalidateDelayed(40)
    }

    private fun dp(v: Float) = v * resources.displayMetrics.density
}

private class Calculator(private val input: String) {
    private var pos = 0
    private fun skip() { while (pos < input.length && input[pos].isWhitespace()) pos++ }
    private fun eat(c: Char): Boolean {
        skip()
        if (pos < input.length && input[pos] == c) { pos++; return true }
        return false
    }

    fun parse(): Double {
        val value = expression()
        skip()
        if (pos != input.length) error("Unexpected character")
        return value
    }

    private fun expression(): Double {
        var x = term()
        while (true) {
            x = when {
                eat('+') -> x + term()
                eat('-') -> x - term()
                else -> return x
            }
        }
    }

    private fun term(): Double {
        var x = power()
        while (true) {
            x = when {
                eat('*') -> x * power()
                eat('/') -> {
                    val d = power()
                    if (d == 0.0) error("Division by zero")
                    x / d
                }
                else -> return x
            }
        }
    }

    private fun power(): Double {
        var x = unary()
        if (eat('^')) x = Math.pow(x, power())
        return x
    }

    private fun unary(): Double {
        if (eat('+')) return unary()
        if (eat('-')) return -unary()
        var x = atom()
        if (eat('%')) x /= 100.0
        return x
    }

    private fun atom(): Double {
        if (eat('(')) {
            val x = expression()
            if (!eat(')')) error("Missing )")
            return x
        }
        skip()
        val start = pos
        var dot = false
        while (pos < input.length) {
            val c = input[pos]
            if (c.isDigit()) pos++
            else if (c == '.' && !dot) { dot = true; pos++ }
            else break
        }
        if (start == pos) error("Number expected")
        return input.substring(start, pos).toDouble()
    }
}
